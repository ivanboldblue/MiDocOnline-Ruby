require 'test_helper'

class SpecializationsHelperTest < ActionView::TestCase
end

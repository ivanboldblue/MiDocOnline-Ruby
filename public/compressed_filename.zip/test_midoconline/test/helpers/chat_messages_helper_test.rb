require 'test_helper'

class ChatMessagesHelperTest < ActionView::TestCase
end

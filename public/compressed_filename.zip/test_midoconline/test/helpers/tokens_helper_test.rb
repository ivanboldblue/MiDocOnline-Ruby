require 'test_helper'

class TokensHelperTest < ActionView::TestCase
end

require 'test_helper'

class ChatsHelperTest < ActionView::TestCase
end

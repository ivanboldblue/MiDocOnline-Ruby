require 'test_helper'

class DoctorsHelperTest < ActionView::TestCase
end

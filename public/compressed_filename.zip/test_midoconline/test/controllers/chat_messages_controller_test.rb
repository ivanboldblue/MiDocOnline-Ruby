require 'test_helper'

class ChatMessagesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end

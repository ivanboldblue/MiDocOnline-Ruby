require 'test_helper'

class CardDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

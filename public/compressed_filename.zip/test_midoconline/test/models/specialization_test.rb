require 'test_helper'

class SpecializationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

# Be sure to restart your server when you modify this file.

Midoconline::Application.config.session_store :cookie_store, key: '_midoconline_session'

var QBApp = {
  appId: 35038,
  authKey: 'yVQnaBUHBuHHr9B',
  authSecret: '4TWZa9b4vRSeudf'
};

var CONFIG = {
  chatProtocol: {
    active: 2,
  },
  debug: true,
  webrtc: {
    answerTimeInterval: 60,
    dialingTimeInterval: 5
  }
};

var QBCallerUser = [
  ]

var QBUsers = [
  
];
var CurrentUsr = 1
var CurrentUsrId = 0
var CurrentUsrType = 'Patient' 


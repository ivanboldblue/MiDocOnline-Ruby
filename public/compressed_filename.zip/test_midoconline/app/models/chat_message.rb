class ChatMessage < ActiveRecord::Base

end

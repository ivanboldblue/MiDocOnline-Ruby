class Device < ActiveRecord::Base
end

class Admin < User
  
	
  
end


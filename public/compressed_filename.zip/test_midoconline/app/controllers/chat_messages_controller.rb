class ChatMessagesController < ApplicationController
end
